public class Foo {

	public static boolean check(){
		return false;
	}
}
