import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FooTest {

	@Test
	public void test(){
		Assertions.assertTrue(Foo.check());
	}

}