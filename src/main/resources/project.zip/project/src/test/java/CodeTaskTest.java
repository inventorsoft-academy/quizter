class CodeTaskTest {

}