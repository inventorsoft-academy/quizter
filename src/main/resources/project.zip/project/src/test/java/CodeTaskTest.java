
class CodeTaskTest {

}